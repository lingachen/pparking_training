#pragma once

#define VERSION		(char *)"VER 1.0.0"