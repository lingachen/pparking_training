#pragma once

typedef unsigned long		DWORD;
typedef unsigned short		WORD;
typedef unsigned char		BYTE;
typedef unsigned int		UNINT32;
typedef struct sockaddr_in	SOCKADDR_IN;
typedef sockaddr			SOCKADDR;
typedef int					SOCKET;